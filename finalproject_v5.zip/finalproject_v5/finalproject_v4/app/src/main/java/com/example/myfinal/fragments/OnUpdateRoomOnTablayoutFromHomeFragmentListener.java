package com.example.myfinal.fragments;

public interface OnUpdateRoomOnTablayoutFromHomeFragmentListener {
    void onUpdateRoomOnTablayoutFromHomeFragment();
}
