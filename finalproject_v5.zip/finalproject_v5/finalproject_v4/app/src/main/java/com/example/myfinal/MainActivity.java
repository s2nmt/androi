package com.example.myfinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myfinal.adapters.ViewPager2AdapterMain;
import com.example.myfinal.databases.DatabaseHandler;
import com.example.myfinal.fragments.ShowRoomInMainListener;
import com.example.myfinal.fragments.OnAddRoomListener;
import com.example.myfinal.fragments.OnRoomUpdateListener;
import com.example.myfinal.fragments.OnUpdateRoomOnTablayoutFromHomeFragmentListener;
import com.example.myfinal.fragments.RoomFragment;
import com.example.myfinal.models.DeviceItem;
import com.example.myfinal.models.RoomItem;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;
import com.example.myfinal.fragment_rooms.TabLayoutFragment;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RoomFragment.OnTabClickListener,
        OnAddRoomListener, OnRoomUpdateListener, OnUpdateRoomOnTablayoutFromHomeFragmentListener
        , ShowRoomInMainListener {
    List<RoomItem> listRoom;
    private ViewPager2 viewPager2;
    private BottomNavigationView bottomNavigationView;

    ViewPager2AdapterMain viewPager2Adapter;

//    db
    public DatabaseHandler databaseHandler;

    public FloatingActionButton floatingActionButton;

    private String alertDialogTitle = "Thêm phòng";

    public int state = 0;


//    Mặc định giá trị
    public String tabNameRoom = "-1xyz";
    public int idRoom = -1;


    List<RoomItem> tempListRoom;

    public int checkcheck;


//    interface for add room --------------
    private OnAddRoomListener onAddRoomListener;

    public void setOnAddRoomListener(OnAddRoomListener listener) {
        this.onAddRoomListener = listener;
    }
//    -------------------------

//    interface for update room on tablayout

    private OnRoomUpdateListener onRoomUpdateListener;

    public void setOnRoomUpdateListener(OnRoomUpdateListener listener) {
        this.onRoomUpdateListener = listener;
    }

//    -----------------------------



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkcheck = 0;


        //change

//        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable(new ColorDrawable(getColor(R.color.blue)));
//        imageView =findViewById(R.id.imageView);
//        button = findViewById(R.id.floatingActionButton);
//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                ImagePicker.with(MainActivity.this)
//                        .crop()                    //Crop image(Optional), Check Customization for more option
//                        .compress(1024)            //Final image size will be less than 1 MB(Optional)
//                        .maxResultSize(1080, 1080)    //Final image resolution will be less than 1080 x 1080(Optional)
//                        .start();
//
//            }
//        });


//        db
        databaseHandler = new DatabaseHandler(this);

        tempListRoom = databaseHandler.getAllRoom();

        if (!tempListRoom.isEmpty()) {
            // ? có nên thêm cập nhật Share ref ở đây không
            String resTabNameRoom = tempListRoom.get(0).getRoomName();
            tabNameRoom = resTabNameRoom;
            idRoom = databaseHandler.getIdRoomByName(tabNameRoom);
        } else {
            // Xóa SharePreferences khi chưa có phòng
            SharedPreferences preferencesRoom = this.getSharedPreferences("ListRoom", Context.MODE_PRIVATE);

            SharedPreferences.Editor editorRoom = preferencesRoom.edit();
            // Để xóa 1 key
//            editorRoom.remove("keyToRemove");
            // Để xóa toàn bộ
            editorRoom.clear();

            editorRoom.apply();
//
//            tabNameRoom = "-1xyz";
//            idRoom = -1;
        }



        floatingActionButton = findViewById(R.id.fl_action_button);

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        viewPager2 = findViewById(R.id.view_pager_2_main);


//        Sử dụng ViewPager2
        viewPager2Adapter = new ViewPager2AdapterMain(this, getSupportFragmentManager());
        viewPager2.setAdapter(viewPager2Adapter);

//        DeviceItem newDevice = new DeviceItem(1, "xy", 1,
//                0,false, 1, 6);
//        databaseHandler.addDevice(newDevice);

        System.out.println("Hiện tại :" + viewPager2.getCurrentItem());



//        Xử lý khi click vào icon
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if (id == R.id.bottom_home){
                    state = 0;
                    viewPager2.setCurrentItem(0);
                } else if (id == R.id.bottom_rooms){
                    state = 1;
                    viewPager2.setCurrentItem(1);

//                    tempListRoom = databaseHandler.getAllRoom();
//
//                    System.out.println(tempListRoom);
//                    boolean a = tempListRoom.isEmpty();
//                    System.out.println(!a);
//                    boolean b = !a;
//                    System.out.println(!b);
//
//                    if (!tempListRoom.isEmpty()) {
//                        String resTabNameRoom = tempListRoom.get(0).getRoomName();
//                        tabNameRoom = resTabNameRoom;
//                        idRoom = databaseHandler.getIdRoomByName(tabNameRoom);
//                    } else {
//                        tabNameRoom = "-1xyz";
//                        idRoom = -1;
//                    }
                } else if (id == R.id.bottom_notifications){
                    state = 2;
                    viewPager2.setCurrentItem(2);
                } else if (id == R.id.bottom_profile){
                    state = 3;
                    viewPager2.setCurrentItem(3);
                }
                return true;
            }
        });

//        Xử lý khi vuốt chuyển tab thì icon cũng chuyển theo
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                switch (position) {
                    case 0:
                        state = 0;
                        bottomNavigationView.getMenu().findItem(R.id.bottom_home).setChecked(true);
                        Toast.makeText(MainActivity.this, "state " + state , Toast.LENGTH_SHORT).show();
                        break;
                    case 1:
                        state = 1;
                        bottomNavigationView.getMenu().findItem(R.id.bottom_rooms).setChecked(true);

//                        tempListRoom = databaseHandler.getAllRoom();
//
//                        if (!tempListRoom.isEmpty()) {
//                            String resTabNameRoom = tempListRoom.get(0).getRoomName();
//                            tabNameRoom = resTabNameRoom;
//                            idRoom = databaseHandler.getIdRoomByName(tabNameRoom);
//                        } else {
//                            tabNameRoom = "-1xyz";
//                            idRoom = -1;
//                        }
                        Toast.makeText(MainActivity.this, "statetttt " + state , Toast.LENGTH_SHORT).show();
                        break;
                    case 2:
                        state = 2;
                        bottomNavigationView.getMenu().findItem(R.id.bottom_notifications).setChecked(true);
                        break;
                    case 3:
                        state = 3;
                        bottomNavigationView.getMenu().findItem(R.id.bottom_profile).setChecked(true);
                        break;
                }
            }
        });

//        floating button
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(MainActivity.this, "hihihih", Toast.LENGTH_SHORT).show();

                if(state == 0) {
//                    Toast.makeText(MainActivity.this, "h1", Toast.LENGTH_SHORT).show();
                    showAddRoomDialogRoom();
                } else if (state == 1) {
                    tempListRoom = databaseHandler.getAllRoom();
                    if (tempListRoom.isEmpty()) {
                        Toast.makeText(MainActivity.this, "Vui lòng thêm phòng trước!", Toast.LENGTH_SHORT).show();
                    } else {
                        showAddRoomDialogDevice();
                    }
                }
            }
        });

    }

    private void showAddRoomDialogRoom() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        SharedPreferences preferencesRoom = this.getSharedPreferences("ListRoom", Context.MODE_PRIVATE);
        String value = preferencesRoom.getString("current_room_name", "NoData");

        builder.setTitle("Thêm phòng " + value);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        // name room
        final EditText input = new EditText(this);
        input.setHint("Tên phòng");
        layout.addView(input);

        // text
        TextView chooseTypeText = new TextView(this);
        chooseTypeText.setText("Chọn loại phòng: ");
        chooseTypeText.setGravity(Gravity.CENTER);
        layout.addView(chooseTypeText);

        // spinner type room
        final Spinner spinner = new Spinner(this);
        List<String> options = new ArrayList<>();
        options.add("Phòng khách");     //0
        options.add("Phòng ngủ");       //1
        options.add("Phòng tắm");       //2
        options.add("Phòng bếp");       //3
        options.add("Loại phòng khác"); //4

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, options);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        layout.addView(spinner);

        builder.setView(layout);

        // to debug
        List<Fragment> fragments = getSupportFragmentManager().getFragments();
        System.out.println(fragments);
        System.out.println(fragments.size());
        // ---------

        List<RoomItem> listCheckRoomEmpty = databaseHandler.getAllRoom();

        System.out.println(listCheckRoomEmpty);


        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String roomName = input.getText().toString();
                String selectedOptionRoom = spinner.getSelectedItem().toString();

                if (roomName.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Vui lòng nhập tên phòng", Toast.LENGTH_SHORT).show();
                    dialog.cancel();
                    return;
                }

                if (selectedOptionRoom.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Vui lòng chọn một loại phòng", Toast.LENGTH_SHORT).show();
                    dialog.cancel();
                    return;
                }

                List<RoomItem> testListRoom = databaseHandler.getAllRoom();
                boolean resultCheckDuplicate = checkDuplicate(testListRoom, roomName);

                if(resultCheckDuplicate) {
                    Toast.makeText(MainActivity.this, "Tên phòng đã tồn tại", Toast.LENGTH_SHORT).show();
                    dialog.cancel();
                    return;
                }

                if (onAddRoomListener != null) {
                    onAddRoomListener.onAddRoom(roomName, selectedOptionRoom);

                    if(onRoomUpdateListener != null) {
                        onRoomUpdateListener.onUpdateRoomOnTablayout();
                    }
//                    updateRoomOnTablayout();
//                    tempListRoom = databaseHandler.getAllRoom();
//                    tabNameRoom = tempListRoom.get(0).getRoomName();

                    if (listCheckRoomEmpty.isEmpty()) {
                        // Cập nhật lại Share ref
                        SharedPreferences preferencesRoom = getSharedPreferences("ListRoom", Context.MODE_PRIVATE);

                        SharedPreferences.Editor editorRoom = preferencesRoom.edit();
                        editorRoom.putString("current_room_name", roomName);
                        editorRoom.apply();
                    }

                    dialog.dismiss();
                } else {
                    Toast.makeText(MainActivity.this, "Lỗi thêm phòng ", Toast.LENGTH_SHORT).show();
                    return;
                }

            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }
    private void showAddRoomDialogDevice() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        SharedPreferences preferencesRoom = this.getSharedPreferences("ListRoom", Context.MODE_PRIVATE);
        String value = preferencesRoom.getString("current_room_name", "NoData");
        tabNameRoom = value;

        idRoom = databaseHandler.getIdRoomByName(tabNameRoom);

        builder.setTitle(tabNameRoom + " Thêm thiết bị " + idRoom );

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        final EditText inputName = new EditText(this);
        inputName.setHint("Tên thiết bị");
        layout.addView(inputName);

        // text
        TextView chooseTypeText = new TextView(this);
        chooseTypeText.setText("Chọn loại thiết bị: ");
        chooseTypeText.setGravity(Gravity.CENTER);
        layout.addView(chooseTypeText);

        // spinner type device
        final Spinner spinner = new Spinner(this);
        List<String> options = new ArrayList<>();
        options.add("Quạt");
        options.add("Điều hòa");
        options.add("Bóng đèn");
        options.add("Tivi");
        options.add("Máy nghe nhạc");
        options.add("Thiết bị khác");



        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, options);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        layout.addView(spinner);

        // text
        TextView gpioTypeText = new TextView(this);
        gpioTypeText.setText("Nhập GPIO: ");
        gpioTypeText.setGravity(Gravity.CENTER);
        layout.addView(gpioTypeText);

        final EditText inputGpio = new EditText(this);
        inputGpio.setHint("GPIO");
        layout.addView(inputGpio);

        builder.setView(layout);


        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

//                Toast.makeText(MainActivity.this, "thêm vài", Toast.LENGTH_SHORT).show();
                String deviceName = inputName.getText().toString();
                String selectedOptionDevice = spinner.getSelectedItem().toString();
                String gpio = inputGpio.getText().toString();

                if (deviceName.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Vui lòng nhập tên thiết bị", Toast.LENGTH_SHORT).show();
                    dialog.cancel();
                    return;
                }
                if (gpio.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Vui lòng nhập GPIO", Toast.LENGTH_SHORT).show();
                    dialog.cancel();
                    return;
                }
                if (selectedOptionDevice.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Vui lòng chọn một loại phòng", Toast.LENGTH_SHORT).show();
                    dialog.cancel();
                    return;
                }

                List<DeviceItem> testListDevice = databaseHandler.getAllDeviceByRoom(idRoom);
//                List<String> gpioSelected = databaseHandler.get

                if(checkDuplicateDivceInRoom(testListDevice, deviceName)) {
                    Toast.makeText(MainActivity.this, "Tên thiết bị đã bị trùng trong phòng", Toast.LENGTH_SHORT).show();
                    dialog.cancel();
                } else {
                    DeviceItem newDevice = new DeviceItem(1, deviceName, selectedOptionDevice,
                            0,false, 1, idRoom, gpio);

                    addDeviceToTab(tabNameRoom, newDevice);

                    dialog.dismiss();
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }

    public DatabaseHandler getDatabaseHandler() {
        return databaseHandler;
    }

    @Override
    public void onTabClick(String tabName) {
        tabNameRoom = tabName;
        idRoom = databaseHandler.getIdRoomByName(tabNameRoom);

        Toast.makeText(MainActivity.this, "Tab selected: " + idRoom + " " + tabNameRoom, Toast.LENGTH_SHORT).show();
    }


//    private void updateRoomOnTablayout() {
//        Fragment roomFragment = getSupportFragmentManager().findFragmentByTag("f1");
//        System.out.println(roomFragment);
//        if (roomFragment != null && roomFragment instanceof RoomFragment) {
//            ((RoomFragment) roomFragment).updateRoomOnTablayout();
//        }
//    }




    private void addDeviceToTab(String tabName, DeviceItem newDevice) {
        TabLayoutFragment tabLayoutFragment = findTabLayoutFragment(tabName);
        if (tabLayoutFragment != null) {
            tabLayoutFragment.addDevice(newDevice);
        }
    }

    private TabLayoutFragment findTabLayoutFragment(String tabName) {
        // Lấy danh sách các fragment hiện tại từ FragmentStateAdapter
        List<Fragment> fragments = new ArrayList<>();

        int allRoom = databaseHandler.getAllRoom().size();
//        viewPager2Adapter.getItemCount()
        for (int i = 0; i < (allRoom); i++) {
            Fragment fragment = getSupportFragmentManager().findFragmentByTag("f" + i);
            fragments.add(fragment);
        }

        System.out.println(fragments);

        // Tìm fragment có tên là tabName
        for (Fragment fragment : fragments) {
            if (fragment instanceof TabLayoutFragment) {
                TabLayoutFragment tabFragment = (TabLayoutFragment) fragment;
                if (tabFragment.getNameRoom().equals(tabName)) {
                    return tabFragment;
                }
            }
        }
        return null;
    }

    public boolean checkDuplicate(List<RoomItem> listRoom, String nameRoom) {
        int lengthListRoom = listRoom.size();
        for (int i = 0; i < lengthListRoom; i++) {
            if ((listRoom.get(i).getRoomName()).equals(nameRoom)) {
                return true;
            }
        }
        return false;
    }

    public boolean checkDuplicateDivceInRoom(List<DeviceItem> listDevice, String nameDevice) {
        int lengthListDevice = listDevice.size();
        for (int i = 0; i < lengthListDevice; i++) {
            if ((listDevice.get(i).getNameDevice()).equals(nameDevice)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onAddRoom(String roomName, String typRoom) {

    }

    @Override
    public void onUpdateRoomOnTablayout() {

    }

    @Override
    public void onUpdateRoomOnTablayoutFromHomeFragment() {

    }

    @Override
    public void goToRoomFragment(String tabName) {
        bottomNavigationView.getMenu().findItem(R.id.bottom_rooms).setChecked(true);
        viewPager2.setCurrentItem(1);
        state = 1;
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//
//            }
//        }, 100);

    }
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        Uri uri = data.getData();
//        imageView.setImageURI(uri);
//    }
}