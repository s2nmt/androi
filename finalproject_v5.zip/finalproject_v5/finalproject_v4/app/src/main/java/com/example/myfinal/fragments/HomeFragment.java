package com.example.myfinal.fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfinal.MainActivity;
import com.example.myfinal.R;
import com.example.myfinal.adapters.RoomAdapter;
import com.example.myfinal.databases.DatabaseHandler;
import com.example.myfinal.models.RoomItem;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeFragment extends Fragment
        implements RoomAdapter.OnItemClickListener,
        RoomAdapter.OnItemLongClickListener,
        OnAddRoomListener
//        ,OnUpdateRoomOnTablayoutFromHomeFragmentListener
{
    private HomeFragment context;
    private View mView;
    private RecyclerView rcvRoom;
    private RoomAdapter roomAdapter;
    public List<RoomItem> listRoom;
    DatabaseHandler databaseHandler;

    private FragmentManager fragmentManager;


//    c3
    private RoomViewModel roomViewModel;
//    -----------------------

//    direct RoomFrag
    private ShowRoomInMainListener mainActivityListener;

    private CircleImageView imgAvatar ;
    private void showRoomFragment(String tabName) {
        if (mainActivityListener != null) {
            mainActivityListener.goToRoomFragment(tabName);
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof ShowRoomInMainListener) {
            mainActivityListener = (ShowRoomInMainListener) context;
        } else {
            throw new ClassCastException(context.toString() + " must implement MainActivityListener");
        }
    }
//    --------------------



//    public void onAddRoom(String roomName) {
//        addRoom(roomName);
//    }

    public static HomeFragment newInstance(String tag) {
        HomeFragment fragment = new HomeFragment();
//        fragment.setArguments("f_home");

        Bundle args = new Bundle();
        args.putString("tag", tag);
        fragment.setArguments(args);


        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_home, container, false);

//        c3
        roomViewModel = new ViewModelProvider(requireActivity()).get(RoomViewModel.class);
//        -------

//        interface
        ((MainActivity) requireActivity()).setOnAddRoomListener(this);



//        db
        databaseHandler = ((MainActivity) requireActivity()).getDatabaseHandler();

        rcvRoom = mView.findViewById(R.id.rcv_room);

        roomAdapter = new RoomAdapter(requireContext(), this, this, this);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false);
        rcvRoom.setLayoutManager(linearLayoutManager);

        RecyclerView.ItemDecoration decoration = new DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL);
        rcvRoom.addItemDecoration(decoration);


//        listRoom  = new ArrayList<>();
        listRoom = databaseHandler.getAllRoom();

        roomAdapter.setData(listRoom);

        rcvRoom.setAdapter(roomAdapter);

        imgAvatar = mView.findViewById(R.id.img_avatar);
        Cursor cursor = databaseHandler.getUserInformation();
        if (cursor != null && cursor.moveToFirst()){
            int imageUriIndex = cursor.getColumnIndex(DatabaseHandler.KEY_IMAGE_URI);
            if (imageUriIndex != -1) {
                String imageUri = cursor.getString(imageUriIndex);
                // Load and set the image using the image URI
                imgAvatar.setImageURI(Uri.parse(imageUri));
            }
        }
        return mView;
    }

    public void addRoom(String roomName, String typeRoom) {
        //    options.add("Phòng khách");     //0
        //    options.add("Phòng ngủ");       //1
        //    options.add("Phòng tắm");       //2
        //    options.add("Phòng bếp");       //3
        //    options.add("Loại phòng khác"); //4

        // default living room
        RoomItem newRoom = new RoomItem(1, R.drawable.img_living_room, roomName, typeRoom);

        if (typeRoom.equals("Phòng khách")) {
            newRoom = new RoomItem(1, R.drawable.img_living_room, roomName, typeRoom);
        } else if(typeRoom.equals("Phòng ngủ")) {
            newRoom = new RoomItem(1, R.drawable.img_bed_room, roomName, typeRoom);
        } else if(typeRoom.equals("Phòng tắm")) {
            newRoom = new RoomItem(1, R.drawable.img_bed_room, roomName, typeRoom);
        } else if(typeRoom.equals("Phòng bếp")) {
            newRoom = new RoomItem(1, R.drawable.img_kitchen, roomName, typeRoom);
        } else if(typeRoom.equals("Loại phòng khác")) {
            newRoom = new RoomItem(1, R.drawable.img_living_room, roomName, typeRoom);
        }


        databaseHandler.addRoom(newRoom);
        listRoom.add(newRoom);
//        roomAdapter.notifyDataSetChanged();
        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                roomAdapter.notifyDataSetChanged();
            }
        });
    }


//    direct RoomFrag
//    showRoomFragment
    @Override
    public void onItemClick(RoomItem roomItem) {

        String nameRoom = roomItem.getRoomName();
        Toast.makeText(requireContext(), "Đã click vào " + nameRoom, Toast.LENGTH_SHORT).show();

        // Lưu vị trí tab được chọn trước đó
        SharedPreferences preferencesRoom = getActivity().getSharedPreferences("ListRoom", Context.MODE_PRIVATE);

        SharedPreferences.Editor editorRoom = preferencesRoom.edit();
        editorRoom.putString("current_room_name", nameRoom);
        editorRoom.apply();

        // Chuyển qua Room Frag, tuy nhiên chưa qua được tab tương ứng
        showRoomFragment(nameRoom);
        //Đã thêm vào updateRoomOnTablayoutở RoomFragment phần code set tab
        // updateRoomOnTablayout ngoài cập nhật các phần tử, còn cập nhật lại tab đã được chọn
        roomViewModel.updateRoomOnTablayout();
        System.out.println(nameRoom);

    }

//    ----------------

    @Override
    public void onItemLongClick(RoomItem roomItem) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setMessage("Bạn có chắc chắn muốn xóa phòng này?")
                .setPositiveButton("OK", (dialog, which) -> {
                    // Thực hiện xóa phòng
                    deleteRoom(roomItem);

                    // Xóa tất cả thiết bị phòng đó
//                    databaseHandler.deleteAllDeviceByRoomId(roomItem.getRoomId());
//                    int x = roomItem.getRoomId();
//                    System.out.println(x);



                    dialog.dismiss();
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    // Đóng dialog nếu người dùng chọn Cancel
                    dialog.dismiss();
                })
                .create()
                .show();
    }

    private void deleteRoom(RoomItem roomItem) {
        // Xóa phòng từ cơ sở dữ liệu
//        databaseHandler.deleteRoom(roomItem.getRoomId());
        databaseHandler.deleteRoomByName(roomItem.getRoomName());
//        Xoa các thiết bị của phòng đó
//        int roomId = databaseHandler.getIdRoomByName(roomItem.getRoomName());
//        databaseHandler.deleteAllDevicesByRoomId(roomId);

        Toast.makeText(requireContext(), "Đã xóa phòng", Toast.LENGTH_SHORT).show();

        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // Xóa phòng từ danh sách và cập nhật RecyclerView
                listRoom.remove(roomItem);
                roomAdapter.notifyDataSetChanged();
            }
        });
        System.out.println(roomItem);

        // Kiểm tra list phòng trống không, nếu clear toàn bộ thì remove Share ref
        List<RoomItem> tempListRoom = databaseHandler.getAllRoom();

        if (tempListRoom.isEmpty()) {
            // Xóa SharePreferences khi chưa có phòng
            SharedPreferences preferencesRoom = getActivity().getSharedPreferences("ListRoom", Context.MODE_PRIVATE);

            SharedPreferences.Editor editorRoom = preferencesRoom.edit();

            editorRoom.clear();

            editorRoom.apply();

        } else {
            // KHÔNG CẦN XỦA LÝ NHƯ DƯỚI NỮA VÌ
            //- khi xóa cái bị chọn thì mặc định chọn cái sau nó, nếu không có cái sau nữa
            // chọn chọn cái ngay trước nó
            // - khi chọn như vậy thì hàm onTabSelected trong RoomFragment đã được gọi
            // vì thế Share ref đã được cập nhật lại



            // Nếu không trống thì kiểm tra phòng bị xóa trùng với phòng đang lưu trong
            // Share ref không, nếu cos thì set mặc định lại lưu phòng đầu tiên
//            SharedPreferences preferencesRoom = getActivity().getSharedPreferences("ListRoom", Context.MODE_PRIVATE);
//            String value = preferencesRoom.getString("current_room_name", "NoData");
//            if (!value.equals("NoData")) {
//                if (roomItem.getRoomName().equals(value)) {
//                    SharedPreferences.Editor editorRoom = preferencesRoom.edit();
//                    editorRoom.putString("current_room_name", databaseHandler.getAllRoom().get(0).getRoomName());
//                    editorRoom.apply();
//                }
//            }

        }


//        c3
        roomViewModel.updateRoomOnTablayout();
//        --------------

        // Xóa phòng từ danh sách và cập nhật RecyclerView
//        listRoom.remove(roomItem);
//        roomAdapter.notifyDataSetChanged();

//        updateRoomOnTablayout();
//        -------TEST------------
//        C1:
//        FragmentManager fm = getParentFragmentManager(); // hoặc getChildFragmentManager() tùy theo ngữ cảnh
//        RoomFragment fragm = (RoomFragment) fm.findFragmentById(R.id.id_fragment_room);
//        System.out.println(fragm);
//        if (fragm != null) {
//            fragm.updateRoomOnTablayout();
//            Toast.makeText(requireContext(), "ĐÃ cập nhật phòng", Toast.LENGTH_SHORT).show();
//        }

//        c2:
//        RoomFragment roomFragment = RoomFragment.getInstance();
//        System.out.println(roomFragment);
//        RoomFragment.getInstance().updateRoomOnTablayout();



    }

//    @Override
//    public void onUpdateRoomOnTablayoutFromHomeFragment() {
//
//    }


    // hàm thay đổi ở tablayout
    private void updateRoomOnTablayout() {
        Fragment roomFragment = requireActivity().getSupportFragmentManager().findFragmentByTag("f1");
        if (roomFragment != null && roomFragment instanceof RoomFragment) {
            ((RoomFragment) roomFragment).updateRoomOnTablayout();
        }
    }



    @Override
    public void onAddRoom(String roomName, String typeRoom) {
        addRoom(roomName, typeRoom);
    }
}
