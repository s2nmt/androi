package com.example.myfinal.mqtt;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.example.myfinal.databases.DatabaseHandler;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MqttHandler implements MqttCallback{
    private MqttClient client;
    private MqttCallbackListener callbackListener;
    private static final String DEFAULT_BROKER_URL = "tcp://13.228.24.205:1883";
    private static final String DEFAULT_CLIENT_ID = "";

    private DatabaseHandler dbHandler;
    private Context context;
    public void setCallbackListener(MqttCallbackListener listener) {
        this.callbackListener = listener;
    }
    public MqttHandler(Context context) {
        this.context = context;
        this.dbHandler = new DatabaseHandler(context);
    }

    public void connect() {
        try {
            // Set up the persistence layer
            MemoryPersistence persistence = new MemoryPersistence();

            // Retrieve user information from the database
            Cursor cursor = dbHandler.getUserInformation();

            String broker = null; // Set default values to null initially
            String clientId = ""; // Set default client ID
            String topic = "device"; // Set default topic

            // Check if the cursor is not null and move to the first row
            if (cursor != null && cursor.moveToFirst()) {
                // Retrieve values from the cursor based on column indices
                int brokerIndex = cursor.getColumnIndex(DatabaseHandler.KEY_BROKER_INFORMATION);
                int topicIndex = cursor.getColumnIndex(DatabaseHandler.KEY_TOPIC_INFORMATION);

                // Check if the columns exist in the cursor
                if (brokerIndex != -1) {
                    broker = "tcp://" + cursor.getString(brokerIndex);
                }


                if (topicIndex != -1) {
                    topic = cursor.getString(topicIndex);
                }
            }

            // Close the cursor to avoid memory leaks
            if (cursor != null) {
                cursor.close();
            }

            // Initialize the MQTT client
            client = new MqttClient(
                    broker != null ? broker : DEFAULT_BROKER_URL,
                    clientId,
                    persistence);

            // Set up the connection options
            MqttConnectOptions connectOptions = new MqttConnectOptions();
            connectOptions.setCleanSession(true);

            // Set the callback for handling connection events
            client.setCallback(this);

            // Connect to the MQTT broker
            client.connect(connectOptions);

            // Subscribe to the default or retrieved topic
            subscribe();

        } catch (MqttException e) {
            // Handle MQTT exception (printStackTrace is used for demonstration purposes)
            e.printStackTrace();
        }
    }

    public void disconnect() {
        try {
            if (client != null && client.isConnected()) {
                client.disconnect();
            }
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publish(String message) {
        try {
            MqttMessage mqttMessage = new MqttMessage(message.getBytes());
            Cursor cursor = dbHandler.getUserInformation();
            String topic = "device"; // Default topic

            // Check if the cursor is not null and move to the first row
            if (cursor != null && cursor.moveToFirst()) {
                // Retrieve values from the cursor based on column indices
                int topicIndex = cursor.getColumnIndex(DatabaseHandler.KEY_TOPIC_INFORMATION);
                if (topicIndex != -1) {
                    String retrievedTopic = cursor.getString(topicIndex);
                    if (retrievedTopic != null && !retrievedTopic.isEmpty()) {
                        topic = retrievedTopic;
                    }
                }
            }

            client.publish(topic, mqttMessage);
            Log.d("MQtt", "Pub success");
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }


    public void subscribe() {
        try {
            // Retrieve the subscription topic from the database
            Cursor cursor = dbHandler.getUserInformation();
            String topic;
            // Check if the cursor is not null and move to the first row
            if (cursor != null && cursor.moveToFirst()) {
                // Retrieve the subscription topic from the cursor
                int subIndex = cursor.getColumnIndex(DatabaseHandler.KEY_SUB_INFORMATION);
                if (subIndex != -1) {
                    topic = cursor.getString(subIndex);
                } else {
                    topic = "sever"; // Default topic if the column is not found
                }
            } else {
                topic = "sever"; // Default topic if the cursor is null or empty
            }

            Log.d("MQtt", "sub success with topic: " + topic);
            client.subscribe(topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void connectionLost(Throwable cause) {
        Log.d("MQtt", "Connection lost");
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        // Xử lý message trên topic đã subscribe ở đây
        if (callbackListener != null) {
            callbackListener.onMessageArrived(new String(message.getPayload()));
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {

    }
}
