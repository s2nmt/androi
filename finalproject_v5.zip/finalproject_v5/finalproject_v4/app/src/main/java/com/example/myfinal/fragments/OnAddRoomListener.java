package com.example.myfinal.fragments;

public interface OnAddRoomListener {
    void onAddRoom(String roomName, String typeRoom);
}
