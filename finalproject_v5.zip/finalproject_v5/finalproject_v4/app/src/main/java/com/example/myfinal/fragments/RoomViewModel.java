package com.example.myfinal.fragments;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class RoomViewModel extends ViewModel {
    private MutableLiveData<Boolean> roomUpdateLiveData = new MutableLiveData<>();
    public LiveData<Boolean> getRoomUpdateLiveData() {
        return roomUpdateLiveData;
    }
    public void updateRoomOnTablayout() {
        // Gửi thông báo sự thay đổi qua LiveData
        roomUpdateLiveData.setValue(true);
    }


}
