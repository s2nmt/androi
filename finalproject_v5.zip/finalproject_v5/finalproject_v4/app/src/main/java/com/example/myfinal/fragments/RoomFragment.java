package com.example.myfinal.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.viewpager2.widget.ViewPager2;

import com.example.myfinal.MainActivity;
import com.example.myfinal.R;
import com.example.myfinal.adapters.ViewPager2AdapterTabLayout;
import com.example.myfinal.databases.DatabaseHandler;
import com.example.myfinal.fragment_rooms.TabLayoutFragment;
import com.example.myfinal.models.RoomItem;
import com.example.myfinal.mqtt.MqttCallbackListener;
import com.example.myfinal.mqtt.MqttHandler;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.List;

public class RoomFragment extends Fragment implements OnRoomUpdateListener
        ,MqttCallbackListener
    {

//    c3
    private RoomViewModel roomViewModel;
//    -------

    private View mView;
    TextView textViewEnergy;
    TabLayout tabLayout;
    ViewPager2 viewPager2Room;
    ViewPager2AdapterTabLayout viewPager2AdapterTabLayout;
    List<RoomItem> listRoom = new ArrayList<>();

    DatabaseHandler databaseHandler;



    private OnTabClickListener tabClickListener;

    //    interface của click tabname
    public interface OnTabClickListener {
        void onTabClick(String tabName);
    }



//    MQTT
    private static final String BROKER_URL  = "tcp://13.228.24.205:1883";
    private static final String CLIENT_ID = "";
    private MqttHandler mqttHandler;

//    -----------------


//    interface to call updateRoomOnTablayout from MainActivity
    private OnRoomUpdateListener roomUpdateListener;

    @Override
    public void onUpdateRoomOnTablayout() {
        updateRoomOnTablayout();
    }


//    mqtt
   private void publishMessage(String topic, String message){

        mqttHandler.publish(message);
   }
    private void subscribeToTopic() {
        // Subscribe to the topic using MqttHandler
        mqttHandler.subscribe();
    }
    @Override
    public void onMessageArrived( String message) {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                String[] parts = message.split("-");
                    if(parts.length == 2){
                        if(parts[0].toString().equals("diennang") ){
                            textViewEnergy.setText(parts[1] + "KHw");
                        }
                    }

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

    //        mqtt
        mqttHandler = new MqttHandler(requireContext());
        mqttHandler.connect();

        subscribeToTopic();
        mqttHandler.setCallbackListener(this);
        Log.d("MQTT", "MQTT reconnect success");

    }

    @Override
    public void onPause() {
        super.onPause();
        mqttHandler.disconnect();
        Log.d("MQTT Disconnect success", "MQTT Disconnect success");
    }



    public static RoomFragment newInstance(String tag) {
        RoomFragment fragment = new RoomFragment();
        Bundle args = new Bundle();
        args.putString("TAG", tag);
        fragment.setArguments(args);
        return fragment;
    }



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_room, container, false);



//        c3
        // Khởi tạo ViewModel
        roomViewModel = new ViewModelProvider(requireActivity()).get(RoomViewModel.class);

        // Quan sát LiveData để cập nhật UI khi có sự thay đổi
        roomViewModel.getRoomUpdateLiveData().observe(getViewLifecycleOwner(), new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean update) {
                if (update) {
                    updateRoomOnTablayout();
                }
            }
        });

//        ----------------------

//        mqtt
//        mqttHandler = new MqttHandler();
//        mqttHandler.connect(BROKER_URL,CLIENT_ID);
//
//        subscribeToTopic("cmd/energy");
//        mqttHandler.setCallbackListener(this);
//        ------


//        interface
        ((MainActivity) requireActivity()).setOnRoomUpdateListener(this);




        //db
        databaseHandler = ((MainActivity) requireActivity()).getDatabaseHandler();

        listRoom = databaseHandler.getAllRoom();
        System.out.println(listRoom);

        tabLayout = mView.findViewById(R.id.tab_layout);
        viewPager2Room = mView.findViewById(R.id.view_pager_2_room);

        textViewEnergy = mView.findViewById(R.id.text_energy_used);



        // truyền cho adapter list phòng lấy được
        viewPager2AdapterTabLayout = new ViewPager2AdapterTabLayout(requireActivity(), listRoom);

        viewPager2Room.setAdapter(viewPager2AdapterTabLayout);

        onAttach(requireContext());


        new TabLayoutMediator(tabLayout, viewPager2Room, new TabLayoutMediator.TabConfigurationStrategy() {
            @Override
            public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
                //Truy xuất từ db

                int mountRoom = listRoom.size();
                int k = 6;
                for(int i = 0; i < mountRoom; i++) {
                    if(i == position) {
                        String nameRoom = listRoom.get(i).getRoomName();
                        tab.setText(nameRoom);
                        break;
                    }
                }
            }
        }).attach();

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
//                int currentTabPosition = tabLayout.getSelectedTabPosition();
                String tabName = tab.getText().toString();
                if (tabClickListener != null) {
                    tabClickListener.onTabClick(tabName);
                    Toast.makeText(requireContext(), "Đã chọnnnnn", Toast.LENGTH_SHORT).show();


                    // Lưu vị trí tab được chọn trước đó
                    SharedPreferences preferencesRoom = getActivity().getSharedPreferences("ListRoom", Context.MODE_PRIVATE);

                    SharedPreferences.Editor editorRoom = preferencesRoom.edit();
                    editorRoom.putString("current_room_name", tabName);
                    editorRoom.apply();
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


        // Lấy tab đã được chọn trước đó và load lên khi mở lại ứng dụng
        SharedPreferences preferencesRoom = getActivity().getSharedPreferences("ListRoom", Context.MODE_PRIVATE);

        String valueCurrentRoom = preferencesRoom.getString("current_room_name", "NoData");
        // Nếu có dữ liệu
        if (!(valueCurrentRoom.equals("NoData"))) {
            // Lặp qua từng tab để tìm tab cần set mặc định
            for (int i = 0; i < tabLayout.getTabCount(); i++) {
                TabLayout.Tab tab = tabLayout.getTabAt(i);
                if (tab != null && tab.getText() != null && tab.getText().toString().equals(valueCurrentRoom)) {
                    // Nếu tìm thấy tab cần set mặc định, thì chọn nó
                    tab.select();
                    break;
                }
            }
        }
        System.out.println(valueCurrentRoom);

        // Chỉnh layout trên thanh tablayout
        int countRoom = listRoom.size();
        if (countRoom > 4) {
            tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);
        }
        else {
            tabLayout.setTabMode(TabLayout.MODE_FIXED);
        }

        return mView;
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            tabClickListener = (OnTabClickListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + " must implement OnTabClickListener");
        }
    }

    public void updateRoomOnTablayout() {
        if (isDetached()) {
            // Fragment đã detach, không thực hiện cập nhật
            return;
        }

        SharedPreferences preferencesRoom = getActivity().getSharedPreferences("ListRoom", Context.MODE_PRIVATE);

        String valueCurrentRoom = preferencesRoom.getString("current_room_name", "NoData");
        // Nếu có dữ liệu
        if (!(valueCurrentRoom.equals("NoData"))) {
            // Lặp qua từng tab để tìm tab cần set mặc định
            for (int i = 0; i < tabLayout.getTabCount(); i++) {
                TabLayout.Tab tab = tabLayout.getTabAt(i);
                if (tab != null && tab.getText() != null && tab.getText().toString().equals(valueCurrentRoom)) {
                    // Nếu tìm thấy tab cần set mặc định, thì chọn nó
                    tab.select();
                    break;
                }
            }
        }

        Toast.makeText(requireContext(), "Đã gọi cập nhật lại phòng", Toast.LENGTH_SHORT).show();
        // Cập nhật danh sách các phòng từ cơ sở dữ liệu
        listRoom = databaseHandler.getAllRoom();

        // Thông báo cho adapter về sự thay đổi trong dữ liệu
        if (viewPager2AdapterTabLayout != null) {
            viewPager2AdapterTabLayout.updateRooms(listRoom);
        }

        // Thông báo cho TabLayoutMediator về sự thay đổi trong dữ liệu
        if (tabLayout != null && viewPager2Room != null) {
            new TabLayoutMediator(tabLayout, viewPager2Room, new TabLayoutMediator.TabConfigurationStrategy() {
                @Override
                public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
                    // Truy xuất từ db
                    int mountRoom = listRoom.size();
                    for (int i = 0; i < mountRoom; i++) {
                        if (i == position) {
                            String nameRoom = listRoom.get(i).getRoomName();
                            tab.setText(nameRoom);
                            break;
                        }
                    }
                }
            }).attach();
            int countRoom = listRoom.size();
            if (countRoom > 4) {
                tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);
            }
            else {
                tabLayout.setTabMode(TabLayout.MODE_FIXED);
            }
        }
    }
}
