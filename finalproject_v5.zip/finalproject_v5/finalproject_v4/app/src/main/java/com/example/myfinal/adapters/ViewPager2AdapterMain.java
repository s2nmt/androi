package com.example.myfinal.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.myfinal.R;
import com.example.myfinal.fragments.HomeFragment;
import com.example.myfinal.fragments.NotificationFragment;
import com.example.myfinal.fragments.ProfileFragment;
import com.example.myfinal.fragments.RoomFragment;

import java.util.ArrayList;
import java.util.List;

public class ViewPager2AdapterMain extends FragmentStateAdapter {
    private FragmentManager fragmentManager;
    public ViewPager2AdapterMain(@NonNull FragmentActivity fragmentActivity, @NonNull FragmentManager fragmentManager) {
        super(fragmentActivity);
        this.fragmentManager = fragmentManager;
    }


    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 0:
//                HomeFragment homeFragment = HomeFragment.newInstance("f_home");
//                    getSupportFragmentManager().beginTransaction()
//                            .replace(R.id.id_main_layout, homeFragment.getClass(), null,  "f_home")
//                            .addToBackStack("f_home")
//                            .commit();
//                return homeFragment;
                return HomeFragment.newInstance("f_home");
            case 1:
                return RoomFragment.newInstance("f_room");
            case 2:
                return NotificationFragment.newInstance("f_notification");
            case 3:
                return ProfileFragment.newInstance("f_profile");
            default:
                return HomeFragment.newInstance("f_home");
        }

//        return new NotificationFragment();
    }


    @Override
    public int getItemCount() {
        return 4;
    }

    public FragmentManager getSupportFragmentManager() {
        return fragmentManager;
    }

}
