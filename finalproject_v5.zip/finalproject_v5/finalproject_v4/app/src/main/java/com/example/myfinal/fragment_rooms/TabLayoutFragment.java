package com.example.myfinal.fragment_rooms;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfinal.MainActivity;
import com.example.myfinal.R;
import com.example.myfinal.adapters.DeviceAdapter;
import com.example.myfinal.adapters.fanfragment;
import com.example.myfinal.databases.DatabaseHandler;
import com.example.myfinal.adapters.ConditionerFragment;
import com.example.myfinal.models.DeviceItem;

import java.util.ArrayList;
import java.util.List;

public class TabLayoutFragment extends Fragment
        implements DeviceAdapter.DeviceItemLongClickListener {
    RecyclerView rcvDevices;
    DeviceAdapter deviceAdapter;
    private List<DeviceItem> listDevice;

    int idRoom;
    String nameRoom;
    DatabaseHandler databaseHandler;

//    public static TabLayoutFragment newInstance(String tag) {
//        TabLayoutFragment fragment = new TabLayoutFragment();
//        Bundle args = new Bundle();
//        args.putString("TAG", tag);
//        fragment.setArguments(args);
//        return fragment;
//    }

//    MQTT
//    private static final String BROKER_URL  = "tcp://192.168.43.114:1883";
//    private static final String CLIENT_ID = "123";
//    private MqttHandler mqttHandler;

//    -----------------


    ///note
    public void openDeviceFragment(DeviceItem deviceItem) {
        Fragment newFragment;

        if (deviceItem.getTypeDevice().equals("Quạt")) {
            newFragment = new fanfragment();
        } else if (deviceItem.getTypeDevice().equals("Điều hòa")) {
            newFragment = new ConditionerFragment();
        } else {
            // Xử lý các loại thiết bị khác nếu cần
            return;
        }

        Bundle bundle = new Bundle();
        bundle.putString("deviceName", deviceItem.getNameDevice());
        newFragment.setArguments(bundle);

        FragmentManager fragmentManager = getParentFragmentManager();

        // Đóng fragment hiện tại trước khi thêm fragment mới
        Fragment currentFragment = fragmentManager.findFragmentById(R.id.fragment_container);
        if (currentFragment != null) {
            fragmentManager.beginTransaction().remove(currentFragment).commit();
        }

        // Thêm fragment mới vào stack và hiển thị
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_container, newFragment)
                .addToBackStack(null)
                .commit();
    }
    //.............................

    public TabLayoutFragment(int idRoom, String nameRoom) {
        this.idRoom = idRoom;
        this.nameRoom = nameRoom;
    }



    View mView;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.frament_tablayout, container, false);

////        mqtt
//        mqttHandler = new MqttHandler();
//        mqttHandler.connect(BROKER_URL,CLIENT_ID);
//        mqttHandler.setCallbackListener(this);
//        publishMessage("sever/"+ String.valueOf(idRoom) + "/" + nameRoom ,"1");
////        subscribeToTopic("cmd");
//        mqttHandler.disconnect();

//        -------------
        return mView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rcvDevices = view.findViewById(R.id.rcv_devices);
        //db
        databaseHandler = ((MainActivity) requireActivity()).getDatabaseHandler();

        // ADAPTER
        deviceAdapter = new DeviceAdapter(this, this, databaseHandler);

//        deviceAdapter.setImageClickListener(this);




        int numberOfColumns = 2;
        GridLayoutManager gridLayoutManager = new GridLayoutManager(requireContext(), numberOfColumns);
        rcvDevices.setLayoutManager(gridLayoutManager);

        listDevice = new ArrayList<>();

        // pass listDevice
        listDevice = databaseHandler.getAllDeviceByRoom(idRoom);
        System.out.println(listDevice.size());
        System.out.println(listDevice);

        deviceAdapter.setData(listDevice);
        rcvDevices.setAdapter(deviceAdapter);

    }
// ........................
//    @Override
//    public void onImageClick(DeviceItem deviceItem) {
//        // Xử lý sự kiện nhấp vào hình ảnh của thiết bị
//        if (deviceItem != null && getActivity() != null) {
//            String typeDevice = deviceItem.getTypeDevice();
//
//            // Kiểm tra loại thiết bị và mở fragment tương ứng
//            if (typeDevice.equals("Điều hòa")) {
//                openConditionerFragment();
//            }
//            // Thêm các điều kiện khác cho các loại thiết bị khác nếu cần
//        }
//    }
//
//    private void openConditionerFragment() {
//        // Thay thế fragment hiện tại bằng ConditionerFragment
//        ConditionerFragment conditionerFragment = new ConditionerFragment();
//        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
//        transaction.replace(R.id.fragment_conditioner, conditionerFragment);
//        transaction.addToBackStack(null);
//        transaction.commit();
//    }
    //...................................
    public void addDevice(DeviceItem deviceItem) {
        Toast.makeText(requireContext(), "Đã gọi thêm thiết bị " , Toast.LENGTH_SHORT).show();
        databaseHandler.addDevice(deviceItem);

        deviceAdapter = new DeviceAdapter(this, this, databaseHandler);
        listDevice = databaseHandler.getAllDeviceByRoom(deviceItem.getRoomId());
        // pass listDevice
        System.out.println(listDevice);
        System.out.println(listDevice);
        deviceAdapter.setData(listDevice);
        rcvDevices.setAdapter(deviceAdapter);

//        listDevice.add(deviceItem);
//        deviceAdapter.notifyDataSetChanged();

//        listDevice.clear();
//        listDevice = databaseHandler.getAllDeviceByRoom(deviceItem.getRoomId());
//        deviceAdapter.notifyDataSetChanged();
    }

    public int getIdRoom() {
        return idRoom;
    }
    public String getNameRoom() {
        return nameRoom;
    }


    @Override
    public void onItemLongClick(DeviceItem deviceItem) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setMessage("Bạn có chắc chắn muốn xóa thiết bị này?")
                .setPositiveButton("OK", (dialog, which) -> {
                    // Thực hiện xóa thiết bị

                    Toast.makeText(requireContext(), "Đã gọi xóa thiết bị ", Toast.LENGTH_SHORT).show();
                    deleteDevice(deviceItem);
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();
                })
                .create()
                .show();
    }

    private void deleteDevice(DeviceItem deviceItem) {
        // Xóa thiết bị từ cơ sở dữ liệu
//        databaseHandler.deleteDevice(deviceItem.getDeviceId());
//        int idDeviceRM = databaseHandler.getDeviceIdByRoomIdAndNameDevice(deviceItem.getRoomId(), deviceItem.getNameDevice());
        databaseHandler.deleteDeviceByRoomIdAndNameDeivice(deviceItem.getRoomId(), deviceItem.getNameDevice());

//        DeviceItem deviceItemRemove = new DeviceItem(idDeviceRM, deviceItem.getNameDevice(),
//                                            deviceItem.getTypeDevice(), deviceItem.getValueDevice(),
//                                            deviceItem.isStatusDevice(), deviceItem.getResourceImgDeviceId(),
//                                            deviceItem.getRoomId(), deviceItem.getGpio());
//        listDevice.remove(deviceItemRemove);


        // Xóa thiết bị từ danh sách và cập nhật RecyclerView
//        listDevice.remove(deviceItem);
//
//
//        deviceAdapter.notifyDataSetChanged();
//        System.out.println(listDevice);

//        ------
        listDevice = databaseHandler.getAllDeviceByRoom(deviceItem.getRoomId());
        // pass listDevice

        deviceAdapter.setData(listDevice);
        rcvDevices.setAdapter(deviceAdapter);
        System.out.println(listDevice);
    }

//    mqtt

//
//    @Override
//    public void onDestroy() {
//        mqttHandler.disconnect();
//        super.onDestroy();
//    }

//    private void publishMessage(String topic, String message){
//        Toast.makeText(requireContext(), "Publishing message: " + message, Toast.LENGTH_SHORT).show();
//        mqttHandler.publish(topic,message);
//    }
//    private void subscribeToTopic(String topic) {
//        Toast.makeText(requireContext(), "Subscribing to topic " + topic, Toast.LENGTH_SHORT).show();
//
//        // Subscribe to the topic using MqttHandler
//        mqttHandler.subscribe(topic);
//    }

//    @Override
//    public void onMessageArrived(String topic, String message) {
//        Log.d("MQTT", "Message arrived on topic: " + topic + ", message: " + message);
//    }
}
