package com.example.myfinal.fragments;

public interface ShowRoomInMainListener {
    void goToRoomFragment(String tabName);
}
