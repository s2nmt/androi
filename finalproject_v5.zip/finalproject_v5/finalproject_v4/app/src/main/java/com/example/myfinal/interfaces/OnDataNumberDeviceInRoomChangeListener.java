package com.example.myfinal.interfaces;

public interface OnDataNumberDeviceInRoomChangeListener {
    void onDataChanged(int roomId);
}
