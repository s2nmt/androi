package com.example.myfinal.fragments;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.myfinal.R;
import com.example.myfinal.databases.DatabaseHandler;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Objects;

public class ProfileFragment extends Fragment {
    private View mView;
    private FloatingActionButton fabProfile;
    private ImageView imageView;
    private EditText editTextUsername;
    private EditText editTextEmail;
    private EditText editTextPhone;
    private EditText editTextGender;
    private EditText editTextBirth;
    private EditText editTextBroker;
    private EditText editTextTopic;
    private EditText editTextSub;
    public static ProfileFragment newInstance(String tag) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putString("TAG", tag);
        fragment.setArguments(args);
        return fragment;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_profile, container, false);

        imageView = mView.findViewById(R.id.imageView);
        fabProfile = mView.findViewById(R.id.fabProfile);

        editTextUsername = mView.findViewById(R.id.username);
        editTextEmail = mView.findViewById(R.id.email);
        editTextPhone = mView.findViewById(R.id.phone);
        editTextGender = mView.findViewById(R.id.gender);
        editTextBirth = mView.findViewById(R.id.birth);
        editTextBroker = mView.findViewById(R.id.broker);
        editTextTopic = mView.findViewById(R.id.topic);
        editTextSub = mView.findViewById(R.id.sub);

        fabProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImagePicker.with(ProfileFragment.this) // Change MainActivity.this to ProfileFragment.this
                        .crop()
                        .compress(1024)
                        .maxResultSize(1080, 1080)
                        .start();
            }
        });

        Button saveButton = mView.findViewById(R.id.save_button);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve user input from UI components
                String username = editTextUsername.getText().toString().trim();
                String email = editTextEmail.getText().toString().trim();
                String phone = editTextPhone.getText().toString().trim();
                String gender = editTextGender.getText().toString().trim();
                String birth = editTextBirth.getText().toString().trim();
                String broker = editTextBroker.getText().toString().trim();
                String topic = editTextTopic.getText().toString().trim();
                String sub = editTextSub.getText().toString().trim();

                Toast.makeText(getActivity(),"hello Success", Toast.LENGTH_SHORT).show();
                // Save or update user information in the database
                saveOrUpdateUserInformation(username, email, phone, gender, birth, broker, topic,sub);
            }
        });
        // Retrieve user information from the database
        DatabaseHandler dbHandler = new DatabaseHandler(getActivity());
        Cursor cursor = dbHandler.getUserInformation();

        if (cursor != null && cursor.moveToFirst()) {
            // User information exists in the database, populate the UI components
            int usernameIndex = cursor.getColumnIndex(DatabaseHandler.KEY_USER_INFORMATION);
            int emailIndex = cursor.getColumnIndex(DatabaseHandler.KEY_EMAIL_INFORMATION);
            int phoneIndex = cursor.getColumnIndex(DatabaseHandler.KEY_PHONE_INFORMATION);
            int genderIndex = cursor.getColumnIndex(DatabaseHandler.KEY_GENDER_INFORMATION);
            int birthIndex = cursor.getColumnIndex(DatabaseHandler.KEY_BIRTH_INFORMATION);
            int brokerIndex = cursor.getColumnIndex(DatabaseHandler.KEY_BROKER_INFORMATION);
            int topicIndex = cursor.getColumnIndex(DatabaseHandler.KEY_TOPIC_INFORMATION);
            int subIndex = cursor.getColumnIndex(DatabaseHandler.KEY_SUB_INFORMATION);
            // Check if the columns exist in the cursor
            if (usernameIndex != -1) {
                String username = cursor.getString(usernameIndex);
                editTextUsername.setText(username);
            }

            if (emailIndex != -1) {
                String email = cursor.getString(emailIndex);
                editTextEmail.setText(email);
            }

            if (phoneIndex != -1) {
                String phone = cursor.getString(phoneIndex);
                editTextPhone.setText(phone);
            }

            if (genderIndex != -1) {
                String gender = cursor.getString(genderIndex);
                editTextGender.setText(gender);
            }

            if (birthIndex != -1) {
                String birth = cursor.getString(birthIndex);
                editTextBirth.setText(birth);
            }

            if (brokerIndex != -1) {
                String broker = cursor.getString(brokerIndex);
                editTextBroker.setText(broker);
            }

            if (topicIndex != -1) {
                String topic = cursor.getString(topicIndex);
                editTextTopic.setText(topic);
            }
            if (subIndex != -1) {
                String sub = cursor.getString(subIndex);
                editTextSub.setText(sub);
            }
        }

        // Close the cursor to avoid memory leaks
        if (cursor != null) {
            cursor.close();
        }


        return mView;
    }
    private void saveOrUpdateUserInformation(String username, String email, String phone, String gender, String birth, String broker, String topic, String sub) {
        DatabaseHandler dbHandler = new DatabaseHandler(getActivity());

        // Check if user information already exists
        Cursor cursor = dbHandler.getUserInformation();
        if (cursor != null && cursor.getCount() > 0) {
            // Update existing user information
            dbHandler.updateUserInformation(username, email, phone, gender, birth, broker, topic,sub);
            Toast.makeText(getActivity(),"Save Success", Toast.LENGTH_SHORT).show();

        } else {
            // Save new user information
            dbHandler.addUserInformation(username, email, phone, gender, birth, broker, topic,sub);
            Toast.makeText(getActivity(),"Save Success", Toast.LENGTH_SHORT).show();
        }

        // Optionally, you can show a toast or perform other actions after saving/updating
        // For example, showToast("User information saved/updated successfully");
    }

        @Override
        public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Uri uri = data.getData();
        imageView.setImageURI(uri);
    }
}
