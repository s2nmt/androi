package com.example.myfinal.fragments;

public interface OnRoomUpdateListener {
    void onUpdateRoomOnTablayout();
}
