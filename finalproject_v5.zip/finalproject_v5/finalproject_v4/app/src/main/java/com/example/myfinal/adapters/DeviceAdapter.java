package com.example.myfinal.adapters;

import static androidx.core.content.ContentProviderCompat.requireContext;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.SwitchCompat;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfinal.MainActivity;
import com.example.myfinal.R;
import com.example.myfinal.databases.DatabaseHandler;
import com.example.myfinal.fragment_rooms.TabLayoutFragment;
import com.example.myfinal.fragments.RoomFragment;
import com.example.myfinal.models.DeviceItem;
import com.example.myfinal.mqtt.MqttCallbackListener;
import com.example.myfinal.mqtt.MqttHandler;

import java.util.List;

public class DeviceAdapter extends RecyclerView.Adapter<DeviceAdapter.DeviceViewHolder>
    implements MqttCallbackListener
    {
    private List<DeviceItem> mListDevice;
    private TabLayoutFragment mContext;
    private DeviceItemLongClickListener itemClickListener;
    private DatabaseHandler databaseHandler;

//    MQTT
        private static final String BROKER_URL  = "tcp://13.228.24.205:1883";
        private static final String CLIENT_ID = "";
        private MqttHandler mqttHandler;

//    -----------------

    public DeviceAdapter(TabLayoutFragment mContext, DeviceItemLongClickListener itemClickListener,
                         DatabaseHandler databaseHandler) {
        this.mContext = mContext;
        this.itemClickListener = itemClickListener;
        this.databaseHandler = databaseHandler;
    }


//    mqtt
    @Override
    public void onMessageArrived( String message) {

    }


    public interface DeviceItemLongClickListener {
        void onItemLongClick(DeviceItem deviceItem);
    }

    public void setData(List<DeviceItem> list){
        this.mListDevice = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DeviceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.device_item, parent, false);


        return new DeviceAdapter.DeviceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DeviceViewHolder holder, int position) {
        DeviceItem deviceItem = mListDevice.get(position);
        if (deviceItem == null) {
            return; //-> không làm gì cả
        }

        holder.gpioDevice.setText(deviceItem.getGpio());
        holder.nameDevice.setText(deviceItem.getNameDevice());
        holder.switchDevice.setChecked(deviceItem.isStatusDevice());

        /////...............................
        // note
        holder.icDevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Gọi phương thức để mở Fragment mới khi người dùng nhấn vào hình ảnh
                mContext.openDeviceFragment(deviceItem);
            }
        });



        // click vào switch
        holder.switchDevice.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                int roomId = deviceItem.getRoomId();
                String nameRoom = databaseHandler.getRoom(roomId).getRoomName();
                if (isChecked) {
                    Toast.makeText(mContext.requireContext(), "Tên phòng khi bật là: " + nameRoom, Toast.LENGTH_SHORT).show();
                    // mqtt
                    mqttHandler = new MqttHandler(mContext.requireContext());
                    mqttHandler.connect();



                    String gpioPub = databaseHandler.getGpioDevice(deviceItem.getDeviceId());

                    if (gpioPub.length() < 2) {
                        gpioPub = "0" + gpioPub;
                    }


                    Log.d("mqtt","payload" + gpioPub + "-1");

                    publishMessage("LCTRL-01-" + gpioPub + "-ER");
                    mqttHandler.disconnect();
;



                    updateDeviceStatus(deviceItem.getRoomId(), deviceItem.getNameDevice(), true);
                } else {
                    Toast.makeText(mContext.requireContext(), "Tên phòng khi tắt là: " + nameRoom, Toast.LENGTH_SHORT).show();
                    // mqtt

                    mqttHandler = new MqttHandler(mContext.requireContext());
                    mqttHandler.connect();

                    String gpioPub = databaseHandler.getGpioDevice(deviceItem.getDeviceId());
                    if (gpioPub.length() < 2) {
                        gpioPub = "0" + gpioPub;
                    }


                    Log.d("mqtt","payload" + gpioPub + "- 0");
                    publishMessage("LCTRL-01-" + gpioPub + "-OK");
                    mqttHandler.disconnect();


                    updateDeviceStatus(deviceItem.getRoomId(), deviceItem.getNameDevice(), false);
                }

            }
        });

        String typeDevice = deviceItem.getTypeDevice();

        // default img
        int imgId = R.drawable.ic_device_orther;
//        options.add("Quạt");
//        options.add("Điều hòa");
//        options.add("Bóng đèn");
//        options.add("Tivi");
//        options.add("Máy nghe nhạc");
//        options.add("Thiết bị khác");


        if (typeDevice.equals("Quạt")) {
            imgId = R.drawable.ic_fan;
        } else if (typeDevice.equals("Điều hòa")) {
            imgId = R.drawable.ic_air_conditioner;
        } else if (typeDevice.equals("Bóng đèn")) {
            imgId = R.drawable.ic_bulb;
        } else if (typeDevice.equals("Tivi")) {
            imgId = R.drawable.ic_tivi;
        } else if (typeDevice.equals("Máy nghe nhạc")) {
            imgId = R.drawable.ic_music;
        } else if (typeDevice.equals("Thiết bị khác")) {
            imgId = R.drawable.ic_device_orther;
        }

        holder.icDevice.setImageResource(imgId);
    }

    @Override
    public int getItemCount() {
        if (mListDevice != null) {
            return mListDevice.size();
        }
        return 0;
    }

    public class DeviceViewHolder extends RecyclerView.ViewHolder {
        private TextView nameDevice, gpioDevice;
        private SwitchCompat switchDevice;

        private ImageView icDevice;

        public DeviceViewHolder(@NonNull View itemView) {
            super(itemView);

            nameDevice = itemView.findViewById(R.id.name_device);
            switchDevice = itemView.findViewById(R.id.switch_device);
            icDevice = itemView.findViewById(R.id.ic_device);
            gpioDevice = itemView.findViewById(R.id.gpio_device);

            itemView.setOnLongClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && itemClickListener != null) {
                    itemClickListener.onItemLongClick(mListDevice.get(position));
                    return true;
                }
                return false;
            });

        }
    }


    private void updateDeviceStatus(int roomId, String nameDevice, boolean status) {
        databaseHandler.updateDeviceStatusByRoomIdAndNameDevice(roomId, nameDevice, status);
    }
//    mqtt
    private void publishMessage( String message){
        mqttHandler.publish(message);
    }

}
