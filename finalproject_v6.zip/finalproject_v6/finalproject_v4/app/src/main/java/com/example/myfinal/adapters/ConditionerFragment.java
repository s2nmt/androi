package com.example.myfinal.adapters;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.myfinal.R;
import com.example.myfinal.mqtt.MqttCallbackListener;
import com.example.myfinal.mqtt.MqttHandler;

public class ConditionerFragment extends Fragment implements MqttCallbackListener {
    private View mView;
    private ProgressBar gaugeProgressBar;
    private TextView gaugeText;
    private MqttHandler mqttHandler;
    TextView textView_progressBar;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_conditioner, container, false);

        // Khởi tạo thanh công cụ (Toolbar)
        Toolbar toolbar = mView.findViewById(R.id.toolbar);

        // Thiết lập thanh công cụ làm ActionBar
        ((AppCompatActivity) requireActivity()).setSupportActionBar(toolbar);

        // Thêm nút back và thiết lập sự kiện nhấn nút back
        ((AppCompatActivity) requireActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Xử lý sự kiện khi nhấn nút back
                requireActivity().onBackPressed();
            }
        });

        // Nhận dữ liệu từ Bundle
        Bundle bundle = getArguments();
        if (bundle != null) {
            String deviceName = bundle.getString("deviceName");
            // Bạn có thể sử dụng dữ liệu này để thực hiện các hành động cần thiết
            updateToolbarTitle(deviceName); // Cập nhật tiêu đề thanh công cụ với deviceName
        }

        // Ánh xạ view của gaugeProgressBar và gaugeText ở đây...
        gaugeProgressBar = mView.findViewById(R.id.gaugeProgressBar);
        textView_progressBar = mView.findViewById(R.id.gaugeText);
        return mView;
    }
    private void subscribeToTopic() {
        // Subscribe to the topic using MqttHandler
        mqttHandler.subscribe();
    }
    @Override
    public void onMessageArrived( String message) {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                String[] parts = message.split("-");
                if(parts.length == 2){
                    if(parts[0].toString().equals("temp_dht") ){
                        updateGauge(Integer.valueOf(parts[1]));
                    }
                }

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        //        mqtt
        mqttHandler = new MqttHandler(requireContext());
        mqttHandler.connect();

        subscribeToTopic();
        mqttHandler.setCallbackListener(this);
        Log.d("MQTT", "MQTT reconnect success");

    }

    @Override
    public void onPause() {
        super.onPause();
        mqttHandler.disconnect();
        Log.d("MQTT Disconnect success", "MQTT Disconnect success");
    }

    public void updateGauge(int progressValue) {
        if (gaugeProgressBar != null) {
            gaugeProgressBar.setProgress(progressValue*2);
            textView_progressBar.setText(String.valueOf(progressValue) + "°C");
            // Các công việc khác liên quan đến ProgressBar
        }
        // Các công việc khác nếu cần
    }


    private void updateToolbarTitle(String title) {
        AppCompatActivity activity = (AppCompatActivity) requireActivity();
        if (activity.getSupportActionBar() != null) {
            activity.getSupportActionBar().setTitle(title);
        }
    }
}