package com.example.myfinal.mqtt;

public interface MqttCallbackListener {
    void onMessageArrived(String message);
}
