package com.example.myfinal.adapters;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.myfinal.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class fanfragment extends Fragment {
    private View mView;
    CircleImageView circleImageView;
    Button btnon;
    Button btnoff;
    private SeekBar seekBar;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_fan, container, false);

        seekBar = mView.findViewById(R.id.seekBar);

        // Khởi tạo thanh công cụ (Toolbar)
        Toolbar toolbar = mView.findViewById(R.id.toolbar);

        // Thiết lập thanh công cụ làm ActionBar
        ((AppCompatActivity) requireActivity()).setSupportActionBar(toolbar);
//        SeekBar seekBar = mView.findViewById(R.id.seekBar);

         circleImageView = mView.findViewById(R.id.fan_img);
         btnon = mView.findViewById(R.id.on_fan);
         btnoff = mView.findViewById(R.id.off_fan);

         seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
             @Override
             public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                 updateRotationSpeed(progress);
             }

             @Override
             public void onStartTrackingTouch(SeekBar seekBar) {

             }

             @Override
             public void onStopTrackingTouch(SeekBar seekBar) {

             }
         });

        btnon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onanimation();
            }
        });
        btnoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                offanimation();
            }
        });


        // Thêm nút back và thiết lập sự kiện nhấn nút back
        ((AppCompatActivity) requireActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Xử lý sự kiện khi nhấn nút back
                requireActivity().onBackPressed();
            }
        });

        // Nhận dữ liệu từ Bundle
        Bundle bundle = getArguments();
        if (bundle != null) {
            String deviceName = bundle.getString("deviceName");
            // Bạn có thể sử dụng dữ liệu này để thực hiện các hành động cần thiết
            updateToolbarTitle(deviceName); // Cập nhật tiêu đề thanh công cụ với deviceName
        }

        // Ánh xạ view của gaugeProgressBar và gaugeText ở đây...

        return mView;
    }

    private void onanimation(){
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                circleImageView.animate().rotationBy(360).withEndAction(this).setDuration(5000)
                        .setInterpolator(new LinearInterpolator()).start();

            }
        };
        circleImageView.animate().rotationBy(360).withEndAction(runnable).setDuration(5000)
                .setInterpolator(new LinearInterpolator()).start();


    }
    private void offanimation(){
        circleImageView.animate().cancel();

    }

    private void updateToolbarTitle(String title) {
        AppCompatActivity activity = (AppCompatActivity) requireActivity();
        if (activity.getSupportActionBar() != null) {
            activity.getSupportActionBar().setTitle(title);
        }
    }
    private void updateRotationSpeed(int progress) {
        // Tính toán tốc độ quay dựa trên giá trị của SeekBar
        float rotationSpeed = progress * 100; // Điều chỉnh hệ số theo nhu cầu

        // Áp dụng tốc độ quay vào hình ảnh
        circleImageView.animate().rotationBy(rotationSpeed).setInterpolator(new LinearInterpolator()).start();
    }

}